/-
  MicroTensor.lean — Minimal tensor expression IR for verified algebra.

  This must match shared/ir.md and julia/MicroTensor.jl exactly.
  The types are deliberately simple (no dependent indices) for the MVP.
-/

/-- Index position: upper (contravariant) or lower (covariant). -/
inductive Position where
  | up
  | down
  deriving Repr, BEq, DecidableEq

/-- A tensor index: a name and a position. -/
structure Index where
  name : String
  position : Position
  deriving Repr, BEq, DecidableEq

/-- Tensor expression IR. Binary sums, no products (MVP). -/
inductive TExpr where
  | zero : TExpr
  | scalar : Int → Int → TExpr   -- numerator, denominator (rational)
  | tensor : String → List Index → TExpr
  | smul : Int → Int → TExpr → TExpr  -- coeff num, den, inner expr
  | sum : TExpr → TExpr → TExpr
  deriving Repr, BEq

/-- Symmetry declaration for a tensor. -/
inductive Symmetry where
  | antisym : String → Nat → Nat → Symmetry  -- tensor name, slot1, slot2
  | sym : String → Nat → Nat → Symmetry
  deriving Repr, BEq

/-- A registry is just a list of symmetry declarations. -/
def Registry := List Symmetry

/-- Check if a registry declares antisymmetry for given tensor and slots. -/
def Registry.hasAntisym (reg : Registry) (name : String) (s1 s2 : Nat) : Bool :=
  reg.any fun
    | .antisym n a b => n == name && a == s1 && b == s2
    | _ => false

/-- Swap two elements in a list by index (0-based in Lean). -/
def List.swap (l : List α) (i j : Nat) : List α :=
  let a := l.get? i
  let b := l.get? j
  match a, b with
  | some va, some vb =>
    l.enum.map fun (k, v) =>
      if k == i then vb
      else if k == j then va
      else v
  | _, _ => l
