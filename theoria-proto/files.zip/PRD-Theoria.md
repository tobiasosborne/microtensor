# Theoria — Product Requirements Document

**Agent-first automated theoretical physics: from symmetries to predictions**

Version 0.1 — March 2026
Status: Draft

---

## 1. Problem statement

Theoretical physics has a computational bottleneck. The intellectual pipeline — specify a theory, derive its consequences, check consistency, compare to data — is well-defined and in principle algorithmic, yet each step currently requires months of specialist labour. The xAct→TensorGR.jl port demonstrated that a single evening of agent-first development can replicate years of accumulated Mathematica tooling. The question is whether this scales from one package to an entire discipline's computational infrastructure.

The answer is constrained by a structural observation: **the forward pipeline (theory → predictions) is deterministic given its inputs.** There are no creative decisions after the theory is specified and the background is chosen. Every step — variational derivatives, perturbative expansion, Feynman rules, loop integrals, renormalisation — is an algorithm operating on symbolic expressions. The human contribution is at the endpoints: choosing which theory to study (taste) and interpreting the results (insight). Everything between is compilation.

The opportunity is not merely to automate the forward pipeline, but to **close the loop**: use the automated pipeline as a subroutine inside a search over theory space, filtered by computable consistency conditions and observational data, with machine-checked proofs of key identities. The output is not "here is the prediction of theory X" but "here is the landscape of viable theories satisfying constraints Y, with verified proofs."

### What TensorGR.jl taught us

The following lessons are load-bearing for the design:

**L1. Architecture decisions are the bottleneck, not code generation.** The TensorGR.jl PRD took longer than the implementation. At agent-first rates (~2000 lines/hour, ~15:1 spec-to-code ratio), a 1200-line PRD produces ~18,000 lines of tested code. The spec is the leverage point. This PRD must therefore be precise about interfaces, data structures, and dependency order — not about implementation details.

**L2. The IR is the product.** TensorGR.jl succeeded because its intermediate representation (S-expression AST + symbol registry + permutation-group metadata) maps almost 1:1 onto both the mathematical objects and Julia's native data model. The choice of IR determines what's easy and what's hard downstream. Getting the IR wrong means rewriting everything; getting it right means domain packages fall out naturally.

**L3. Julia's specific conjunction matters.** S-expression AST, multiple dispatch, zero-cost C FFI, and compile-time macros together enable ports that would be infeasible in other languages. This is not language advocacy — it's a technical constraint on the design space. The system is Julia or it doesn't work.

**L4. Registry over parametric types.** Metadata (symmetries, representations, quantum numbers) lives in a runtime dictionary keyed by symbol, not in the type system. This avoids combinatorial explosion while preserving dispatch on the AST node types that matter for algorithmic branching.

**L5. Three-layer architecture.** Raw `Expr` escape hatch → typed AST with dispatch → compiled C/Fortran via `ccall`. The escape hatch is non-negotiable: it prevents the type system from ever blocking working code. The `@refactor` protocol tracks technical debt without accumulating it.

**L6. Mathematical self-reinforcement provides test coverage.** In tensor algebra, errors propagate rapidly through downstream identities. A test suite built on known mathematical identities (Bianchi, trace-freeness, gauge invariance) catches most bugs even with incomplete line coverage. This principle extends to all of theoretical physics: the web of consistency conditions is denser than in ordinary software.

**L7. FFI over reimplementation.** Use `ccall` to existing algorithmic C/Fortran cores (xperm.c, FORM, Kira, FIRE) rather than reimplementing. The wrapper is ~200 lines; the algorithm is ~3000 lines of battle-tested C.

**L8. Agent-first development requires explicit dependency DAGs.** Claude Code parallelises well when the PRD specifies which components are independent. Sequential bottlenecks must be identified and minimised.

---

## 2. Goals and non-goals

### Goals

**G1.** Build a composable stack of Julia packages that collectively automate the forward pipeline: theory specification → action construction → perturbative expansion → Feynman rules → loop computation → renormalisation → physical predictions. Each package is independently useful.

**G2.** Design the shared IR (the "OpenCAS layer") so that domain packages (gravity, gauge theory, supergravity, cosmology) are independent downstream consumers of a common algebraic engine.

**G3.** Enable the **inverse pipeline**: parametric search over theory space, filtered by computable consistency predicates (unitarity, ghost freedom, anomaly cancellation, causality bounds), constrained by observational data.

**G4.** Emit Lean 4 proof obligations for algebraic identities discovered during computation, enabling machine-checked verification of key results.

**G5.** All packages open-source, registered in the Julia General registry, with no proprietary dependencies (no Mathematica, no FORM license, no Maple).

**G6.** Agent-first throughout: every package is designed to be generated, tested, and extended by Claude Code given a PRD. Human role is architecture, review, and directing search.

### Non-goals

**N1.** We do not solve the Einstein evolution equations (numerical relativity). We take metrics as input.

**N2.** We do not build a general-purpose CAS to compete with Mathematica/Maple for non-physics applications. The IR is optimised for indexed algebraic objects with symmetry structure.

**N3.** We do not build a lattice field theory code. The pipeline is perturbative and symbolic.

**N4.** We do not build a numerical cross-section calculator (like MadGraph/Sherpa). We produce symbolic expressions that could feed into such tools. A numerical evaluation layer is future work.

**N5.** We do not attempt to automate the choice of *which* theory to study. The human provides the search space; the system explores it.

**N6.** We do not handle 2D CFT (worldsheet string theory, conformal bootstrap) — the computational objects (conformal blocks, modular functions) are not indexed tensors and require a fundamentally different IR.

---

## 3. Architecture

### 3.1 Package stack

The system is a stack of Julia packages with explicit dependency relationships. Each package has a single responsibility and a well-defined interface.

```
┌──────────────────────────────────────────────────────────────────┐
│  Layer 5: Search & Verification                                  │
│  ┌─────────────┐ ┌──────────────┐ ┌──────────────────────────┐  │
│  │ TheoriaSearch│ │ TheoriaLean  │ │ TheoriaData              │  │
│  │ (theory space│ │ (Lean 4 proof│ │ (observational           │  │
│  │  enumeration │ │  export)     │ │  constraints: PDG, GWTC, │  │
│  │  & filtering)│ │              │ │  Planck)                 │  │
│  └─────────────┘ └──────────────┘ └──────────────────────────┘  │
├──────────────────────────────────────────────────────────────────┤
│  Layer 4: Physics Applications                                   │
│  ┌───────────┐ ┌───────────┐ ┌────────────┐ ┌───────────────┐  │
│  │ TensorGR  │ │FeynCalc.jl│ │ SUGRA.jl   │ │ Cosmology.jl  │  │
│  │ (gravity, │ │(QFT:      │ │(spinors,   │ │(FLRW, inflation│  │
│  │ curvature,│ │ Feynman   │ │ Clifford,  │ │ perturbations) │  │
│  │ higher-   │ │ rules,    │ │ Fierz,     │ │               │  │
│  │ derivative│ │ diagrams, │ │ superspace)│ │               │  │
│  │ spectra)  │ │ loops)    │ │            │ │               │  │
│  └───────────┘ └───────────┘ └────────────┘ └───────────────┘  │
├──────────────────────────────────────────────────────────────────┤
│  Layer 3: Algebraic Extensions                                   │
│  ┌───────────────┐ ┌────────────────┐ ┌──────────────────────┐  │
│  │ Spinor.jl     │ │ ColourAlg.jl   │ │ LoopIntegrals.jl     │  │
│  │ (Clifford,    │ │ (SU(N), Casimir│ │ (PV reduction, IBP,  │  │
│  │  Dirac trace, │ │  trace, colour │ │  master integrals,   │  │
│  │  Fierz)       │ │  decomposition)│ │  dim reg)            │  │
│  └───────────────┘ └────────────────┘ └──────────────────────┘  │
├──────────────────────────────────────────────────────────────────┤
│  Layer 2: Core Algebra Engine (= current TensorGR.jl core)       │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │  IndexAlgebra.jl                                            │ │
│  │  Typed AST: TensorExpr hierarchy                            │ │
│  │  Index management, contraction, raising/lowering            │ │
│  │  Canonicalisation via xperm.c (Butler-Portugal)             │ │
│  │  Leibniz rule, product rule, symmetry handling              │ │
│  │  Rewrite rule engine (pattern matching, fixed point)        │ │
│  │  Scalar algebra (expand, collect, factor)                   │ │
│  │  Simplification pipeline                                    │ │
│  │  Registry: Dict{Symbol, ObjectProperties}                   │ │
│  │  Exterior calculus (forms, wedge, Hodge, d)                 │ │
│  │  IBP, variation, perturbation (Leibniz partition)           │ │
│  └─────────────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────────────┤
│  Layer 1: Foundations                                             │
│  ┌──────────────────┐ ┌────────────────┐ ┌───────────────────┐  │
│  │ xperm_jll        │ │ Symbolics.jl   │ │ Metatheory.jl     │  │
│  │ (BinaryBuilder   │ │ (scalar CAS    │ │ (e-graph rewriting│  │
│  │  for xperm.c)    │ │  backend)      │ │  — future)        │  │
│  └──────────────────┘ └────────────────┘ └───────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
```

### 3.2 The core IR: IndexAlgebra.jl

This is TensorGR.jl's algebraic engine extracted and generalised. The key generalisation: the IR must handle not just spacetime (Lorentz) indices but also:

- **Spinor indices** (undotted α, dotted α̇, with ε^{AB} contraction)
- **Gauge indices** (colour a,b,c in adjoint; fundamental i,j,k)
- **Internal/flavour indices** (R-symmetry, generation)
- **Grassmann parity** (bosonic/fermionic grading on every node)

The existing `Index` type carries `name::Symbol` and `position::IndexPosition` (Up/Down). The generalisation adds:

```julia
struct Index
    name::Symbol
    position::IndexPosition     # Up / Down
    index_type::IndexType       # Lorentz / SpinorUndotted / SpinorDotted /
                                # GaugeAdj / GaugeFund / Internal
    bundle::Symbol              # :Lorentz, :SU3, :SU2, :R, ...
end
```

The `IndexType` determines which metric/epsilon is used for contraction:
- `Lorentz` → g^{μν}
- `SpinorUndotted` → ε^{AB}
- `SpinorDotted` → ε^{Ȧḃ}
- `GaugeAdj` → δ^{ab}
- `GaugeFund` → δ^{i}_j

This is a modest extension of TensorGR.jl's existing `VBundle` system, which already tracks per-index bundle membership and prevents cross-bundle contraction. The new piece is the contraction metric selection.

**Grassmann parity.** Every `TensorExpr` node carries a `parity::GrassmannParity` field (Even/Odd). The product rule becomes:

```julia
# In TProduct, the sign under permutation of adjacent fermionic factors:
# A_fermionic * B_fermionic = -B_fermionic * A_fermionic
grassmann_sign(perm, parities) = (-1)^(number of transpositions of odd-parity pairs)
```

This affects canonicalisation: `xperm.c` already handles signed permutations (the sign slot in the permutation vector), so Grassmann signs are encoded as additional generators in the symmetry group. Cadabra uses exactly this approach.

**What stays the same:** The AST node types (`Tensor`, `TProduct`, `TSum`, `TScalar`, `TDeriv`), the registry pattern, the simplification pipeline, the rule engine, the escape hatch. These are IR-level decisions that proved correct in TensorGR.jl and do not change.

### 3.3 New AST nodes

Two new node types are needed at the IR level:

```julia
"""
A chain of gamma matrices with open spinor indices.
γ^{μ₁} γ^{μ₂} ⋯ γ^{μₙ} contracted into a spinor bilinear ψ̄ᵅ (⋯) χᵦ.
"""
struct GammaChain <: TensorExpr
    lorentz_indices::Vector{Index}    # the μ₁, ..., μₙ on the gammas
    left_spinor::Index                # open left spinor index (or contracted)
    right_spinor::Index               # open right spinor index (or contracted)
    chirality::Chirality              # None / Left / Right / Gamma5
    parity::GrassmannParity           # always Even (bilinear is bosonic)
end

"""
A trace of gamma matrices: tr(γ^{μ₁} ⋯ γ^{μₙ}).
Simplified by the standard recursive trace reduction algorithm.
"""
struct GammaTrace <: TensorExpr
    lorentz_indices::Vector{Index}
end
```

The simplification rules for these are well-known and finite:
- Clifford algebra: `γ^μ γ^ν + γ^ν γ^μ = 2g^{μν}` (a rewrite rule)
- Trace reduction: `tr(γ^μ γ^ν) = 4g^{μν}`, etc. (recursive algorithm)
- Fierz identity: quartic spinor → sum of bilinear × bilinear (lookup table in 4D)
- Dimensional regularisation: `g^μ_μ = d`, `tr(𝟙) = 2^{⌊d/2⌋}` (symbolic d)

These are *rewrite rules* operating on the existing rule engine, not new algorithmic primitives. The GammaChain type exists to give the rules something to pattern-match against.

### 3.4 Colour algebra: ColourAlg.jl

SU(N) algebra for gauge theory. The fundamental objects:

```julia
struct ColourTrace <: TensorExpr
    generators::Vector{Symbol}      # T^{a₁} T^{a₂} ⋯ T^{aₙ}
    representation::Symbol          # :fundamental, :adjoint
    gauge_group::Symbol             # :SU3, :SU2, :SUN
end
```

Simplification rules:
- `tr(T^a) = 0`
- `tr(T^a T^b) = ½ δ^{ab}`
- `tr(T^a T^b T^c) = ¼(d^{abc} + i f^{abc})`
- `T^a_{ij} T^a_{kl} = ½(δ_{il} δ_{kj} - (1/N) δ_{ij} δ_{kl})`   (Fierz for colour)
- Casimir evaluation: `C_F = (N²-1)/(2N)`, `C_A = N`

This is a small, self-contained package (~500 lines of source, ~300 lines of rules). It depends only on IndexAlgebra.jl for the AST and rule engine.

### 3.5 Loop integrals: LoopIntegrals.jl

This package handles the reduction of tensor loop integrals to scalar master integrals.

**Passarino-Veltman reduction** (one-loop): express tensor integrals $\int d^dk \, k^{\mu_1} \cdots k^{\mu_n} / (D_1 \cdots D_m)$ in terms of scalar integrals $A_0$, $B_0$, $C_0$, $D_0$, ... by decomposing the numerator tensor into metric tensors and external momenta. This is linear algebra — solving a system of equations obtained by contracting with all available tensors. ~1000 lines.

**IBP reduction** (multi-loop): generate integration-by-parts identities $\int d^dk \, \partial/\partial k_i^\mu (\cdots) = 0$, which produce linear relations among integrals with different propagator powers. Solve the resulting (large, sparse) linear system to express all integrals in terms of a finite set of master integrals. This is the Laporta algorithm. The existing Julia ecosystem has some pieces (SymEngine.jl for fast polynomial arithmetic), but the core algorithm needs implementation. Alternatively, FFI to FIRE or Kira (both open-source C++) following L7.

**Master integral evaluation** is out of scope for v0.1 (N4). The output of the pipeline is symbolic expressions in terms of named master integrals ($B_0(p^2, m_1^2, m_2^2)$, etc.) with known analytic results in the literature. A lookup table of standard results suffices for one-loop.

### 3.6 FeynCalc.jl

This is the integration layer that connects everything into a QFT calculation pipeline.

**Inputs:**
- Lagrangian (as a `TensorExpr` involving fields, metrics, covariant derivatives)
- Background (flat, de Sitter, FLRW, Schwarzschild, ...)
- Loop order

**Pipeline:**

1. **Variation** → equations of motion. (IndexAlgebra.jl, exists)
2. **Perturbative expansion** → quadratic, cubic, quartic, ... vertices. (IndexAlgebra.jl, exists for metric; needs generalisation to arbitrary fields)
3. **Feynman rules** → propagators from quadratic part, vertices from higher-order parts. Extract momentum-space expressions via Fourier transform. (New code, ~800 lines. TensorGR.jl's `QuadraticForm` + Fourier transform exists for the graviton case.)
4. **Diagram generation** → enumerate diagrams at the given loop order. Either wrap QGRAF (standard Fortran tool, free, ~200 lines of FFI) or implement direct enumeration for low loop order (~500 lines).
5. **Amplitude evaluation** → for each diagram: substitute Feynman rules, evaluate Dirac traces (Spinor.jl), colour traces (ColourAlg.jl), Lorentz contractions (IndexAlgebra.jl). (~500 lines of orchestration.)
6. **Tensor reduction** → PV or IBP reduction to master integrals. (LoopIntegrals.jl)
7. **Renormalisation** → identify UV poles, compute counterterms, check finiteness. (~500 lines. This is mainly bookkeeping of $1/\epsilon$ poles.)
8. **Physical observables** → cross sections (amplitude squared, phase space integration), beta functions (coefficient of the counterterm), anomalous dimensions. (~300 lines of standard formulas.)

### 3.7 TheoriaSearch: the inverse pipeline

This is the package that closes the loop.

**Theory specification DSL:**

```julia
@theory begin
    spacetime = 4D Lorentzian
    gauge_group = SU(3) × SU(2) × U(1)
    matter = [
        scalar(:H, rep=(1,2,1/2)),           # Higgs doublet
        weyl_fermion(:Q, rep=(3,2,1/6)),     # quark doublet
        # ... etc
    ]
    gravity = metric(:g)
    constraints = [
        max_derivatives = 6,
        power_counting = :renormalisable,     # or :EFT_to_order_n
        discrete_symmetries = [:CPT],
    ]
end
```

**Enumeration:**

Given a specification with free parameters (e.g., "all gauge-invariant operators up to dimension 6"), enumerate the most general Lagrangian. This is a constrained monomial enumeration:

1. List all field monomials up to the specified dimension/derivative order
2. Contract all indices in all gauge-invariant ways (using the representation theory of the gauge group)
3. Impose discrete symmetries to further reduce
4. The result is a parametric Lagrangian $\mathcal{L}(\{c_i\})$ with free Wilson coefficients

This is finite and computable. The Hilbert series / plethystic exponential technique gives the number of independent operators without enumerating them; actual enumeration requires the tensor product decomposition and contraction, which is what IndexAlgebra.jl + ColourAlg.jl provide.

**Consistency filters** (computable predicates on theories):

| Filter | What it checks | Computational cost |
|--------|---------------|-------------------|
| Ghost freedom | No negative-residue poles in the propagator | Cheap: pole analysis of QuadraticForm determinant |
| Tree-level unitarity | Partial-wave amplitudes bounded | Moderate: compute 2→2 amplitudes, partial-wave project |
| Anomaly cancellation | $\text{tr}[T^a \{T^b, T^c\}] = 0$ for gauge anomalies | Cheap: group theory trace |
| Gravitational anomaly | $\text{tr}[T^a] = 0$, mixed anomalies | Cheap: representation data |
| Perturbative unitarity | Optical theorem at one loop | Expensive: one-loop calculation |
| Causality / analyticity | Positivity bounds on EFT coefficients | Moderate: tree-level amplitude, dispersive analysis |
| Vacuum stability | Scalar potential bounded below | Moderate: polynomial optimisation |

Filters are ordered by cost. Cheap filters run first to prune the search space before committing to expensive loop calculations.

**Observational constraints:**

TheoriaData.jl wraps machine-readable experimental data:
- PDG Review of Particle Physics (coupling constants, masses, mixing angles)
- GWTC gravitational wave catalog (posterior samples for source parameters)
- Planck CMB power spectra (TT, TE, EE, lensing)
- LHC cross-section measurements (HEPData)

Each dataset provides a likelihood function $\mathcal{L}(\{c_i\} | \text{data})$ that the search can evaluate given the Wilson coefficients of a candidate theory.

### 3.8 TheoriaLean: machine-checked verification

The pipeline produces algebraic identities:
- "The determinant of the spin-2 kinetic matrix is $p^4$" (polynomial identity)
- "The trace anomaly vanishes for this field content" (linear algebra over integers)
- "The gauge anomaly $\text{tr}[T^a \{T^b, T^c\}]$ cancels between quarks and leptons" (finite sum)
- "The one-loop beta function is $\beta = -7g^3/(16\pi^2)$" (rational arithmetic on Casimirs)

All of these are *decidable* statements — polynomial identities, rational arithmetic, or finite-dimensional linear algebra. Lean 4's `ring`, `norm_num`, `decide`, and `linarith` tactics handle them mechanically.

TheoriaLean.jl:
1. Takes a `TensorExpr` identity (LHS = RHS)
2. Translates to a Lean 4 theorem statement
3. Attempts automatic proof via the appropriate tactic
4. Reports: proved / failed / timeout
5. On success, emits a `.lean` file that can be independently checked

The translation is the hard part. TensorExpr → Lean Expr requires:
- Mapping Julia types to Lean types (straightforward for scalars, polynomials, matrices)
- Encoding index contractions as matrix multiplications or summations
- Representing the symmetry structure (this is where it gets nontrivial for Riemann-type identities)

For v0.1, restrict to: polynomial identities in explicit scalar variables (no free indices). This covers propagator determinants, anomaly coefficients, beta function coefficients, and Casimir evaluations. Extending to identities with free indices (e.g., Bianchi identity) is v0.2.

---

## 4. Data structures

### 4.1 ObjectProperties (generalised from TensorProperties)

```julia
struct ObjectProperties
    name::Symbol
    manifold::Symbol                        # :M4, :Minkowski, :internal, ...
    rank::Tuple{Int,Int}                    # (contravariant, covariant) per index type
    index_types::Vector{IndexType}          # per-slot index type
    symmetries::Vector{PermGroup}           # slot symmetries for xperm.c
    grassmann_parity::GrassmannParity       # Even or Odd
    mass_dimension::Rational{Int}           # [φ] = 1, [ψ] = 3/2, [A_μ] = 1, [g_μν] = 0
    gauge_representation::Any               # (rep_1, rep_2, ...) under each gauge factor
    dependencies::Vector{Symbol}            # other objects this depends on
    is_field::Bool                          # true for dynamical fields (varied in action)
    statistics::Statistics                   # Boson / Fermion / Ghost
end
```

The registry is `Dict{Symbol, ObjectProperties}` as before. Context scoping via `with_registry` is unchanged.

### 4.2 Theory specification

```julia
struct TheorySpec
    name::Symbol
    spacetime_dim::Int
    signature::Tuple{Int,Int}               # (timelike, spacelike), e.g., (1,3)
    gauge_group::GaugeGroup                 # product of simple factors
    fields::Vector{FieldSpec}               # all dynamical fields
    parameters::Vector{Symbol}              # free coupling constants
    action_terms::Vector{TensorExpr}        # the Lagrangian density terms
    symmetries::Vector{DiscreteSym}         # C, P, T, and combinations
    derivative_order::Int                   # max derivatives in action
    background::BackgroundSpec              # flat, dS, AdS, FRW, ...
end
```

This is the input to the entire pipeline. The search layer (TheoriaSearch) produces `TheorySpec` objects; the forward pipeline consumes them.

### 4.3 Computation result

```julia
struct TheoryResult
    spec::TheorySpec
    # Forward pipeline outputs
    eom::Vector{TensorExpr}                 # equations of motion
    propagators::Dict{Symbol, TensorExpr}   # field → propagator
    particle_spectrum::Vector{Particle}      # poles, masses, spins
    vertices::Vector{Vertex}                # Feynman rules
    amplitudes::Dict{Process, TensorExpr}   # computed amplitudes
    beta_functions::Dict{Symbol, TensorExpr}# one-loop beta functions
    # Consistency checks
    ghost_free::Bool
    anomaly_free::Bool
    unitary::Union{Bool, Nothing}           # Nothing if not computed
    # Proof status
    verified_identities::Vector{LeanProof}
    unverified_identities::Vector{TensorExpr}
    # Observational fit
    log_likelihood::Union{Float64, Nothing}
end
```

---

## 5. Dependency DAG and build order

```
                    xperm_jll (BinaryBuilder)
                         │
                    IndexAlgebra.jl          ← EXTRACT from TensorGR.jl
                    │    │    │
        ┌───────────┘    │    └───────────┐
        │                │                │
   Spinor.jl      ColourAlg.jl     LoopIntegrals.jl
        │                │                │
        └───────┬────────┘                │
                │                         │
           FeynCalc.jl ───────────────────┘
                │
   ┌────────────┼────────────┐
   │            │            │
TensorGR.jl  SUGRA.jl  Cosmology.jl      ← domain packages (parallel)
   │            │            │
   └────────────┼────────────┘
                │
        TheoriaSearch.jl
           │         │
    TheoriaLean.jl  TheoriaData.jl
```

### Build phases

**Phase 0: Extract IndexAlgebra.jl from TensorGR.jl.**

This is the critical path. TensorGR.jl currently contains both the general algebra engine and the GR-specific objects (Riemann, Christoffel, metric, curvature) in one package. The extraction moves everything below Layer 3 in the current `src/` into IndexAlgebra.jl, and makes TensorGR.jl a thin domain package that depends on IndexAlgebra.jl.

What moves to IndexAlgebra.jl:
- `types.jl`, `registry.jl`, `show.jl` (with ObjectProperties generalised)
- `ast/` (indices, walk)
- `escape_hatch.jl`
- `rules.jl`
- `xperm/` (wrapper + permutations)
- `algebra/` (arithmetic, contraction, canonicalize, simplify, derivatives, ibp, solve, ansatz, collect_tensors, trace, symmetrize, young)
- `scalar/` (algebra, functions, simplify_cas)
- `exterior/` (forms, operations, connection_forms)
- `perturbation/` (partitions, expand, metric_perturbation, variation, linearize, gauge, backgrounds, isaacson) — generalised to arbitrary fields, not just the metric
- `macros/` (tensor_macro, definitions)
- `parser/` (latex_parser)

What stays in TensorGR.jl:
- `gr/` (curvature, bianchi, metric, covd, sort_covds, box, lie, killing, hypersurface, mapping, topological, conversions, symmetry_ansatz, matter, invariants, product_manifold, metric_ansatz_gen)
- `components/` (ctensor, metric_compute, to_basis, values, symbolic_metric, basis)
- `svt/` (fourier, decompose, projectors)
- `foliation/` (foliation, decompose, svt_rules, constraints, sectors)
- `action/` (quadratic_action, spin_projectors, kernel_extraction, extract_quadratic, svt_quadratic)
- `worldline/` (worldline)
- `geodesics/` (geodesic)

The extraction is mechanical: move files, update `using`/`import`, run existing tests. No algorithmic changes. TensorGR.jl's test suite is the regression gate.

Estimated effort: 1 Claude Code session.

**Phase 1: Grassmann parity + index type generalisation.**

Add `GrassmannParity` to all AST nodes. Add `IndexType` to `Index`. Modify `canonicalize` to pass Grassmann signs to xperm.c via the sign slot. Modify `contract_metrics` to select the contraction metric based on `IndexType`.

This touches many files but each change is local (adding a field, threading it through). The test suite catches regressions immediately.

Estimated effort: 1 Claude Code session.

**Phase 2: Spinor.jl + ColourAlg.jl.** (Parallel — independent of each other.)

Spinor.jl: `GammaChain`, `GammaTrace` types + Clifford algebra rules + Dirac trace algorithm + Fierz identity table + dimensional regularisation (symbolic d).

ColourAlg.jl: `ColourTrace` type + SU(N) simplification rules + Casimir evaluation + colour Fierz.

Both depend only on IndexAlgebra.jl. Both are rule-heavy, algorithm-light. Test against known QFT textbook results (Peskin-Schroeder traces, etc.).

Estimated effort: 1 session each, parallel.

**Phase 3: LoopIntegrals.jl.**

Passarino-Veltman one-loop reduction. Standard algorithm, well-documented. Test against FeynCalc's `TID` output for known processes.

For multi-loop: FFI wrapper to Kira or FIRE6 (both open-source). Kira is C++ with a command-line interface; the wrapper generates input files, runs Kira, parses output.

Estimated effort: 1 session (PV) + 1 session (Kira FFI).

**Phase 4: FeynCalc.jl.** (Depends on Phases 1–3.)

Integration layer. Feynman rule extraction from Lagrangian, diagram generation (QGRAF wrapper or direct enumeration), amplitude evaluation orchestrating Spinor.jl + ColourAlg.jl + IndexAlgebra.jl, renormalisation.

Estimated effort: 2 sessions.

**Phase 5: Domain packages.** (Parallel — all depend on IndexAlgebra.jl + FeynCalc.jl.)

TensorGR.jl: already exists, just needs to depend on IndexAlgebra.jl instead of having it inline.

SUGRA.jl: Spinor.jl applied to gravitino, supergravity Lagrangians, Killing spinor equations.

Cosmology.jl: FLRW perturbation theory, inflation, spectral indices. Much of this is the existing `foliation/` + `svt/` code plus standard slow-roll formulas.

Estimated effort: 1 session each.

**Phase 6: TheoriaSearch + TheoriaLean + TheoriaData.**

Search: operator enumeration via Hilbert series / direct tensor product, filter pipeline, parameter space exploration.

Lean: Julia-to-Lean translation for polynomial identities, tactic dispatch, proof management.

Data: wrappers for PDG, GWTC, Planck, HEPData. Likelihood functions.

Estimated effort: 1 session each.

### Total: ~12 Claude Code sessions

At demonstrated throughput, each session produces ~2000–4000 lines of tested code in ~2–4 hours. The entire system is ~30,000–50,000 lines of source (comparable to xAct's core). Calendar time depends on how many sessions run in parallel and how much PRD work happens between them.

The critical path is: Phase 0 → Phase 1 → Phase 4 → Phase 6. Phases 2, 3, 5 are off the critical path.

---

## 6. Test strategy

### 6.1 Mathematical self-reinforcement (L6)

Every domain has a web of identities that serve as integration tests:

| Domain | Test identities |
|--------|----------------|
| Gravity | Bianchi, contracted Bianchi, Weyl trace-free, metric compatibility |
| Spinors | tr(γ^μ γ^ν) = 4g^{μν}, tr(γ_5 γ^μ γ^ν γ^ρ γ^σ) = 4iε^{μνρσ} |
| Colour | tr(T^a T^a) = C_F × dim(R), completeness relations |
| QFT | Ward identities (gauge invariance of amplitudes), optical theorem |
| SUGRA | Gravitino equation implies Rarita-Schwinger constraint |
| Anomalies | Standard Model anomaly cancellation (known to hold) |
| Renormalisation | One-loop QED β = e³/(12π²) (textbook value) |

A bug in the algebra engine propagates into failure of these identities. The test suite is a theorem prover running backwards: if the known theorems still hold, the engine is probably correct.

### 6.2 Cross-validation against existing tools

For every calculation that has been done in FeynCalc/Mathematica or FORM, reproduce the result and compare symbolically. Differences are bugs.

Priority cross-validation targets:
1. QED one-loop electron self-energy (Peskin-Schroeder §7.1)
2. QCD one-loop gluon self-energy with ghost contribution
3. Graviton one-loop self-energy in pure gravity (known to be finite in 4D at one loop)
4. Standard Model anomaly cancellation (group theory computation)
5. Fourth-derivative gravity propagator (existing TensorGR.jl benchmark)

### 6.3 Lean verification

For every algebraic identity used in a test, emit a Lean proof obligation. The fraction of identities with machine-checked proofs is a quality metric. Target for v0.1: 100% of anomaly coefficients, propagator determinants, and beta function coefficients verified.

---

## 7. Risks and mitigations

### R1: IndexAlgebra.jl extraction breaks TensorGR.jl (HIGH probability, LOW impact)

The extraction will break import paths, module scoping, and test isolation.

**Mitigation**: TensorGR.jl's 3534 tests are the regression gate. Run them after every extraction step. Agent-first refactoring is cheap.

### R2: Grassmann parity is more invasive than expected (MEDIUM probability, MEDIUM impact)

Threading parity through every AST operation may reveal assumptions about commutativity baked into `canonicalize` or `simplify`.

**Mitigation**: Cadabra's source (open, C++) documents exactly how Grassmann signs interact with the Butler-Portugal algorithm. The modification to xperm.c's symmetry generators is well-understood (encode sign in the last slot of the permutation, same as existing TensorGR.jl convention for antisymmetry).

### R3: LoopIntegrals.jl is harder than other packages (MEDIUM probability, HIGH impact)

IBP reduction is algorithmically complex (Laporta's algorithm involves solving very large sparse linear systems) and numerically delicate (Gram determinants can vanish in special kinematics).

**Mitigation**: Use FFI to Kira/FIRE for multi-loop (L7). Implement only PV reduction natively (well-understood, textbook algorithm). The native implementation is ~1000 lines; the FFI wrapper is ~200 lines.

### R4: Lean translation is harder than it appears (MEDIUM probability, LOW impact)

Translating TensorExpr trees to Lean propositions may require more scaffolding than anticipated, especially for identities involving contracted indices.

**Mitigation**: Restrict v0.1 to scalar (no free indices) polynomial identities. This covers the highest-value targets (anomaly cancellation, propagator determinants) and defers the hard problem (tensorial identities) to v0.2.

### R5: The search space is too large (HIGH probability, MEDIUM impact)

The number of gauge-invariant operators grows rapidly with dimension/derivative order. Naive enumeration is infeasible beyond dimension ~8.

**Mitigation**: Use the Hilbert series to compute the *number* of operators before enumerating them. If the number exceeds a threshold, switch from enumeration to parametric analysis (treat the Wilson coefficients as symbols and compute predictions as functions of them, then constrain by data). This is how the EFT program already works in practice.

### R6: Community adoption requires documentation and onboarding (CERTAIN, MEDIUM impact)

A powerful tool that nobody else can use is a private notebook.

**Mitigation**: Documenter.jl for all packages. Tutorial notebooks reproducing published results. The "show don't tell" publication strategy: papers where the tool is the method, not the subject.

---

## 8. Success criteria

The system succeeds at v0.1 if:

1. **QED one-loop**: the pipeline computes the electron self-energy, vertex correction, and vacuum polarisation at one loop, reproduces the standard beta function β = e³/(12π²), and the Lean bridge verifies the anomaly cancellation for one generation of leptons.

2. **Graviton propagator**: TensorGR.jl (now on IndexAlgebra.jl) reproduces all existing benchmarks without regression. The sixth-derivative gravity particle spectrum computation still works.

3. **Standard Model anomaly cancellation**: TheoriaSearch enumerates the SM field content, ColourAlg.jl computes all anomaly traces, and TheoriaLean emits verified Lean proofs that they cancel.

4. **Theory space scan**: given "all ghost-free parity-even higher-derivative gravities up to 6th order," the system enumerates the viable parameter space and reproduces the known result (5-dimensional for flat background).

5. **All packages install via `Pkg.add`** with no proprietary dependencies.

6. **Agent-first reproducibility**: each package has a PRD from which Claude Code can regenerate the implementation. The PRD-to-code ratio remains ≥ 10:1.

---

## 9. Naming

Working name: **Theoria** (θεωρία — "contemplation, speculation, a looking at"). The umbrella name covers the search/verification layer. The individual packages have their own names (IndexAlgebra.jl, Spinor.jl, ColourAlg.jl, LoopIntegrals.jl, FeynCalc.jl, TensorGR.jl, TheoriaSearch.jl, TheoriaLean.jl, TheoriaData.jl).

Open question: whether the namespace should be `Theoria.IndexAlgebra`, `Theoria.Spinor`, etc. (single monorepo with submodules) or fully independent packages. The TensorGR.jl experience suggests independent packages — monorepos create coupling that slows agent-first development. Explicit `Pkg.add` dependencies are the right coupling mechanism.

---

## 10. What this does not do (and why it matters)

This system automates the *computational* content of theoretical physics. It does not automate:

- **Choosing which theory to study.** This is taste, informed by physical intuition, aesthetics, and awareness of the experimental landscape. The system makes taste *cheaper to exercise* — you can explore a conjecture's consequences in minutes instead of months — but it does not replace the conjecture.

- **Interpreting results.** "The parameter space of ghost-free 6-derivative gravity is 5-dimensional" is a fact. "This means higher-derivative gravity is more constrained than previously thought" is an interpretation. The system produces facts; humans produce interpretations.

- **Formulating new principles.** Einstein did not discover general relativity by enumerating all possible theories of gravity. He had a physical insight (equivalence principle) that constrained the search space to a single point. The system can check whether a proposed principle is consistent and what it implies, but it cannot originate principles.

What the system *does* change is the **economics of exploration.** When checking a theory takes months, you check the theories you're most confident about. When checking takes minutes, you can afford to explore theories you think are probably wrong but might surprise you. The history of physics suggests that the surprises are where the progress is.
