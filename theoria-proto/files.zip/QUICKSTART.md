# Getting Started

## Prerequisites

- Julia 1.10+ with JSON.jl: `julia -e 'using Pkg; Pkg.add("JSON")'`
- Lean 4 via elan: `curl https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -sSf | sh`

## Step 1: Try the Lean side first

This is where the unknowns are. Julia just works.

```bash
cd lean/
lake build
```

If this typechecks, the axiom set is coherent and the proof structure works. If it doesn't, the errors will tell you what needs adjusting — likely `DecidableEq` instances, `List.swap` definition, or `native_decide` issues.

**What to expect:** The `Example.lean` proof might need tweaking. Lean's elaborator can be fussy about:
- Implicit argument resolution (you may need to add explicit type annotations)
- The `omega` tactic for `Nat` bounds
- `native_decide` requiring concrete ground terms

This is the most productive first hour: getting `Example.lean` to typecheck tells you everything about whether the approach works.

## Step 2: Run the Julia side

```bash
cd julia/
julia test_emit.jl > ../trace.json 2>log.txt
cat log.txt      # see what happened
cat ../trace.json | python3 -m json.tool  # pretty-print the trace
```

This should produce a JSON trace showing three steps: swap, collect, zero_elim.

## Step 3: Close the loop manually

Read `trace.json`, verify it matches what `Example.lean` does. At this point both sides work independently; the remaining work is automating the bridge (a script that reads JSON and generates .lean source).

## Step 4: Branch and explore

```bash
# Explore tactic-based proofs
git checkout -b lean-tactic
# ... modify Example.lean, try different tactic strategies

# Explore decidability
git checkout -b lean-decide
# ... try: define canon in Lean, use native_decide

# Explore binary IR
git checkout -b julia-binary
# ... change Julia IR to binary throughout, measure perf
```

## What success looks like

1. `lake build` passes in `lean/` → axioms and proof are coherent
2. `julia test_emit.jl` produces a valid trace → computation side works
3. A script turns a trace into a .lean file that typechecks → loop is closed
4. You can add a second identity (e.g., R_{abcd} = R_{cdab}) by adding one axiom and one test → the system extends smoothly

## What failure looks like (and what it teaches)

- **Lean can't typecheck the proof:** the axiom set or proof structure needs adjustment. This is the most likely failure mode. The fix is usually adding more explicit type annotations or adjusting how `List.swap` works.

- **`native_decide` is too slow:** for large index lists, concrete evaluation in the Lean kernel may time out. Switch to having Julia emit explicit equality proofs for list manipulation. This means more data in the trace but less computation in Lean.

- **The trace format is too low-level:** if every simplification step needs 5 trace entries to express, the trace becomes unwieldy. Consider coarser-grained steps ("canonicalise this subtree" rather than individual swaps).

- **The axiom approach feels wrong:** maybe you want theorems from a semantic model. That's the `lean-decide` branch — build a canonicaliser in Lean, prove it correct, skip traces entirely.

Each failure mode points at a specific branch to explore. That's the point of the multi-branch strategy.
