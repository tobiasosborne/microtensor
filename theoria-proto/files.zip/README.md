# theoria-proto

Exploratory prototype: Julia ↔ Lean 4 verified tensor algebra.

**Goal:** close the loop (Julia computes → emits trace → Lean replays → proof certificate) for the simplest nontrivial tensor identity, then see what we learn.

**Target identity:** $R_{abcd} + R_{abdc} = 0$ (Riemann antisymmetry in last pair).

## Branch strategy

Each branch explores a different design choice. Results from each inform the final architecture.

| Branch | Question | Approach |
|--------|----------|----------|
| `main` | — | Shared infrastructure, this README, the JSON schema |
| `lean-tactic` | How well do `rw` chains work as proof scripts? | Lean replayer generates `by rw [...]` proofs |
| `lean-term` | Can we skip tactics and build proof terms directly? | Lean replayer generates explicit `Eq.trans` chains |
| `lean-decide` | Can we make the whole thing decidable? | Encode canonicalisation as a decision procedure, use `native_decide` |
| `julia-binary` | Does binary IR work better than n-ary? | Binary `sum`/`prod` constructors with `sig` caching |
| `julia-nary` | Or is flat vectors better for Julia perf? | Keep current TensorGR.jl style, translate to binary for Lean export |

Start with `lean-tactic` + `julia-nary` (path of least resistance), then explore alternatives.

## Structure

```
shared/
  schema.json          # JSON interchange schema (both sides agree on this)
  ir.md                # IR specification (the contract)
julia/
  MicroTensor.jl       # Minimal tensor IR + simplify + trace emitter
  test_emit.jl         # Emit trace for R_{abcd} + R_{abdc} = 0
lean/
  MicroTensor.lean     # Inductive type + axioms
  Rules.lean           # Verified rewrite rules
  Replay.lean          # Trace replayer
  lakefile.lean        # Build config
scripts/
  prove.sh             # End-to-end: julia → json → lean → proof
```

## Running

```bash
# Julia side: compute and emit trace
julia julia/test_emit.jl > trace.json

# Lean side: replay trace and verify
./scripts/prove.sh trace.json

# Or all at once:
./scripts/prove.sh --from-scratch
```

## Open questions (to be resolved by experimentation)

1. **Binary vs n-ary constructors.** Binary is cleaner for Lean induction. N-ary is faster in Julia. Do we need both representations, or can one serve?

2. **Tactic vs term proofs.** Tactic proofs (`rw`) are readable and easy to generate. Term proofs (`Eq.trans`) are faster to check. At what scale does this matter?

3. **How much registry to export.** Lean needs to know "R has antisymmetry in slots 3,4." Minimal: export only the symmetries used in the trace. Maximal: export the full registry. Which is less painful?

4. **Decidability.** Can we make "these two TExpr are equal" decidable in Lean (by reducing to canonical form comparison)? If yes, proofs become `by native_decide` with no trace needed. But this requires verifying the canonicaliser in Lean, which is much harder.

5. **Where does the proof live?** Options: (a) standalone .lean files checked by CI, (b) embedded in Julia docstrings as certificates, (c) a Lean library that imports all proved identities. Try (a) first.
